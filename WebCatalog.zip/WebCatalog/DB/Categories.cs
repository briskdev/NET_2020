﻿using System;
using System.Collections.Generic;

namespace WebCatalog.Database
{
    public partial class Categories
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
