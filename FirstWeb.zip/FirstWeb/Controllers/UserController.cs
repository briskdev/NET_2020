﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FirstWeb.DB;
using FirstWeb.Models;
using Microsoft.AspNetCore.Mvc;

namespace FirstWeb.Controllers
{
    public class UserController : Controller
    {
        // https://localhost:44304/User/Index
        // https://localhost:44304/User/
        public IActionResult Index()
        {
            using(var db = new DbContext())
            {
                // select Id, Name, Email, Phone from Users
                var users = db.Users.Select(u => new UserModel()
                {
                    Id = u.Id,
                    Name = u.Name,
                    Email = u.Email,
                    Phone = u.Phone,
                }).ToList();
                
                return View(users);
            }
        }

        // https://localhost:44304/User/View/2
        public IActionResult View(int id)
        {
            using(var db = new DbContext())
            {
                // select Id, Name, Email, Phone from Users where Id = @id
                var u = db.Users.Find(id);
                var user = new UserModel()
                {
                    Id = u.Id,
                    Name = u.Name,
                    Email = u.Email,
                    Phone = u.Phone,
                };

                return View(user);
            }
        }

        // https://localhost:44304/User/Add
        [HttpGet]
        public IActionResult Add()
        {
            var user = new UserModel();
            return View(user);
        }

        [HttpPost]
        public IActionResult Add(UserModel model)
        {
            if(ModelState.IsValid)
            {
                using(var db = new DbContext())
                { 
                    // VISS OK - modelis ir valīds, var veikt datu saglabāšanu
                    // insert into Users(Email, Phone, Name)
                    // values(@email, @phone, @name)
                    // COMMIT;
                    db.Users.Add(new Users()
                    {
                        Email = model.Email,
                        Phone = model.Phone,
                        Name = model.Name,
                    });
                    db.SaveChanges();

                    return RedirectToAction("Index");
                }
            }

            return View(model);
        }
    }
}